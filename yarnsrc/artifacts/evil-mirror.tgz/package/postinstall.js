require('fs').writeFileSync('VM1_YARN_SOURCE_EXECUTED','ran')
